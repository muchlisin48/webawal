<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "astra";

$koneksi = mysqli_connect($host, $user, $pass, $db);
?>